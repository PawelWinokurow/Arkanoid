module GameView (module GameView) where

import Geometry
import Textures
import Settings
import GameObjects
import GameCollisions
import Graphics.Gloss
import Graphics.Gloss.Interface.Pure.Game
import Graphics.Gloss.Interface.IO.Game
import Data.List

initGameState :: GameState -> GameState
initGameState game = game
  { ball = Ball { ballPosition = (0, -300), ballVelocity = (0, 700) }
  , paddle = Paddle { paddlePosition = (0, -fromIntegral screenHeight / 2 + 50), paddleVelocityX = 0, paddleWidth = 140 } 
  , score = ("aaa","0")
  , cells = initCells
  , view = GameInProgress
  }

initCells :: [Cell]
initCells = [ Cell { cellPosition = (cellPositionX j, cellPositionY i)
                   , picture      = translate (cellPositionX j) (cellPositionY i) $ color (getColor i) $ rectangleSolid cellWidth cellHeight
                   , row          = i
                   , cellColor    = getColor i
                   } | j <- [0..cellCols-1], i <- [0..cellRows-1]]

update :: Float -> GameState ->  GameState
update seconds = checkEndGame . cellBounce . wallBounce . paddleBounce . moveObjects seconds

render :: GameState  -> Picture
render game = pictures $ [backgroundGameTex (textures game), paddlePicture, ballPicture] ++ map (\cell -> picture cell) (cells game) ++ (showScore game)
  where
    paddlePicture :: Picture
    paddlePicture = uncurry translate (paddlePosition $ paddle game) $ paddleTex $ textures game

    ballPicture :: Picture
    ballPicture = uncurry translate (ballPosition $ ball game) $ ballTex $ textures game

showScore :: GameState -> [Picture]
showScore game = [ pictures $ [translate (scoreLeftOffset + fromIntegral (i * 38)) (fromIntegral screenHeight / 2 - 40) (snd $ (filter (\num -> (fst num) == scoreString!!i) (numsTex (textures game)))!!0) | i <- [0..length scoreString - 1]] ]
  where
    scoreString :: String
    scoreString = snd (score game)

    scoreLeftOffset :: Float
    scoreLeftOffset = (fromIntegral screenWidth / 2 - fromIntegral (length scoreString) * 36)

handleInput :: Event -> GameState -> GameState
handleInput (EventMotion (x, _)) game = movePaddle game x
handleInput _ game = game
        
moveObjects :: Float -> GameState -> GameState
moveObjects seconds game = moveBonus seconds (moveBall seconds game) 

moveBall :: Float -> GameState -> GameState
moveBall seconds game = game { ball = (ball game) { ballPosition = (x', y') }}
  where
    (x, y) = ballPosition $ ball game
    (vx, vy) = ballVelocity $ ball game
    x' = x + vx * seconds
    y' = y + vy * seconds

moveBonus :: Float -> GameState -> GameState
moveBonus seconds game = 
  if (length $ bonuses game) == 0
    then 
      game
    else
      game --{ bonuses = map  (bonuses game) { ballPosition = (x', y') }}
          --random (mkStdGen 949488) :: (Float, StdGen) 

cellBounce :: GameState -> GameState
cellBounce game = complementCells $ removeCollidedCell $ game { ball = (ball game) { ballVelocity = (vx', vy') }, score = (name, scr)}
  where
    (vx, vy) = ballVelocity (ball game)
    (oldName, oldScore) = score game
    vx' = if cellCollision game HorizontalCollision
      then
        -vx
      else
        vx
    vy' = if cellCollision game VerticalCollision
      then
        -vy
      else
        vy  
    (name, scr) = if cellCollision game HorizontalCollision || cellCollision game VerticalCollision
      then
        (oldName, show ((read oldScore ::Int) + 100))
      else
        (oldName, oldScore)
    
    removeCollidedCell :: GameState -> GameState
    removeCollidedCell game = game { cells = removeFirstCollidedCell (cells game) }
    
    removeFirstCollidedCell :: [Cell] -> [Cell]
    removeFirstCollidedCell [] = []
    removeFirstCollidedCell (x:xs) 
        | distanceX (ballPosition $ ball game) (cellPosition x) <= 0 && distanceY (ballPosition $ ball game) (cellPosition x) <= 0 = xs
        | otherwise  = x : removeFirstCollidedCell xs 
        
complementCells :: GameState -> GameState
complementCells game = if lastRow game == cellRows - 1
              then 
                game
              else
                complementCells . addFirstRow . moveRowsDown $ game
  where 
    moveRowsDown :: GameState -> GameState
    moveRowsDown game = 
      game { cells = (map (\cell -> cell { cellPosition = (fst (cellPosition cell), cellPositionY ((row cell) + 1))
                                         , picture      = translate (fst (cellPosition cell)) (cellPositionY ((row cell) + 1)) $ color (cellColor cell) $ rectangleSolid cellWidth cellHeight
                                         , row          = (row cell) + 1
                                        }) (cells game))
      }

    addFirstRow :: GameState -> GameState
    addFirstRow game = 
      game { cells = (cells game) ++ [ Cell { cellPosition = (cellPositionX j, cellPositionY 0)
                                     , picture      = translate (cellPositionX j) (cellPositionY 0) $ color (colorOfFirstRow game) $ rectangleSolid cellWidth cellHeight
                                     , row          = 0
                                     , cellColor    = colorOfFirstRow game
                                     } | j <- [0..cellCols-1]] }

    colorOfFirstRow :: GameState -> Color
    colorOfFirstRow game = nextColor $ cellColor ((filter (\cell -> (row cell) == lastRow game) (cells game))!!0)

    lastRow :: GameState -> Int
    lastRow game = maximum $ map (\cell -> row cell) (cells game)

paddleBounce :: GameState -> GameState
paddleBounce game = game { ball = (ball game) { ballVelocity = (vx', vy') }}
  where
    angle = ((-180) * (1 - alpha)) + (180 * alpha)
    alpha = ((fst (ballPosition $ ball game)) - (fst (paddlePosition $ paddle game))) / (paddleWidth $ paddle game)
    
    (vx, vy) = ballVelocity $ ball game
    (vx', vy') = if paddleCollision game
      then
        (sin(alpha) * 700 , cos(alpha) * 700)
      else
        (vx, vy)

wallBounce :: GameState -> GameState
wallBounce game = game { ball = (ball game) { ballVelocity = (vx', vy') }}
  where
    (vx, vy) = ballVelocity $ ball game
    vx' = if wallCollision game LeftCollision  || wallCollision game RightCollision
      then
        -vx
      else
        vx
    vy' = if wallCollision game TopCollision
      then
        -vy
      else
        vy

checkEndGame :: GameState -> GameState    
checkEndGame game 
  | wallCollision game BottomCollision = game {view = GameOver}
  | otherwise                          = game

movePaddle :: GameState -> Float -> GameState
movePaddle game mousePositionX = 
  game { paddle = (paddle game) { paddlePosition =
    if checkLeftWindowConstraint game mousePositionX && checkRightWindowConstraint game mousePositionX
      then (mousePositionX, y)
      else 
        if not(checkLeftWindowConstraint game mousePositionX)
          then 
            (-fromIntegral screenWidth / 2 + (paddleWidth $ paddle game) / 2, y)
          else 
            (fromIntegral screenWidth / 2 - (paddleWidth $ paddle game) / 2, y)
        , paddleVelocityX = mousePositionX - fst (paddlePosition $ paddle game)
  }}
  where
    y = snd (paddlePosition $ paddle game)

    checkLeftWindowConstraint :: GameState -> Float -> Bool
    checkLeftWindowConstraint game mousePositionX = mousePositionX - (paddleWidth $ paddle game) / 2 >= -fromIntegral screenWidth / 2

    checkRightWindowConstraint :: GameState -> Float -> Bool
    checkRightWindowConstraint game mousePositionX = mousePositionX + (paddleWidth $ paddle game) / 2 <= fromIntegral screenWidth / 2
