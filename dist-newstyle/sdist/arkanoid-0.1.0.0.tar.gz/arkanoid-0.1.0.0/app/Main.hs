module Main where

import Textures
import Settings
import Geometry
import GameObjects
import qualified GameView
import qualified GameOverView
import qualified MainView
import qualified HighScoreView
import Control.Monad
import System.Exit
import Data.Char 
import Graphics.Gloss
import Graphics.Gloss.Interface.Pure.Game
import Graphics.Gloss.Interface.IO.Game
import Data.List.Split

window :: Display
window = InWindow "Arkanoid" (screenWidth, screenHeight) (screenOffset, screenOffset)

main :: IO ()
main = do
  textures <- loadTextures
  highScores <- loadHighScores
  playIO window white fps (initGameState textures highScores) render handleInput update

initGameState :: Textures -> [(String, String)] -> GameState
initGameState textures highScores = Game { textures = textures
                                         , view = MainMenu 
                                         , buttonsHover = Buttons { isNewGameButtonHovered    = False
                                                                  , isHighScoreButtonHovered  = False
                                                                  , isReplayButtonHovered     = False
                                                                  , isSaveButtonHovered       = False
                                                                  , isExitGameButtonHovered   = False
                                                                  , isBackButtonHovered       = False
                                                                  , isMainMenuButtonHovered   = False
                                                                  , isFirstUpButtonHovered    = False
                                                                  , isFirstDownButtonHovered  = False
                                                                  , isSecondUpButtonHovered   = False
                                                                  , isSecondDownButtonHovered = False
                                                                  , isThirdUpButtonHovered    = False
                                                                  , isThirdDownButtonHovered  = False
                                                                  }
                                         , exit = False
                                         , highScores = Scores { save = False, scores = highScores }
                                         , bonuses = []
                                         }
 

update :: Float -> GameState -> IO GameState
update seconds game
  | view game == MainMenu        =  if exit game           
                                      then           
                                        do  
                                          exitWith ExitSuccess
                                          return $ MainView.update seconds game                                                                                                             
                                      else
                                        if save (highScores game)
                                          then
                                            do 
                                              saveHighScore game
                                              return $ MainView.update seconds game {highScores = (highScores game) {save = False}}                                                                                                            
                                          else
                                            return $ MainView.update seconds game   

  | view game == GameInProgress  = return $ GameView.update seconds game
  | view game == GameOver        = return $ GameOverView.update seconds game
  | view game == HighScores      = return $ HighScoreView.update seconds game
  | otherwise                    = return $ GameView.update seconds game
  
render :: GameState  -> IO Picture
render game 
  | view game == MainMenu        = return $ MainView.render game                                                                                                                  
  | view game == GameInProgress  = return $ GameView.render game
  | view game == GameOver        = return $ GameOverView.render game
  | view game == HighScores      = return $ HighScoreView.render game
  | otherwise                    = return $ GameView.render game

handleInput :: Event -> GameState -> IO GameState
handleInput event game
  | view game == MainMenu       = return $ MainView.handleInput event game
  | view game == GameInProgress = return $ GameView.handleInput event game
  | view game == GameOver       = return $ GameOverView.handleInput event game
  | view game == HighScores     = return $ HighScoreView.handleInput event game
  | otherwise                   = return $ GameView.handleInput event game

loadHighScores :: IO [(String, String)]
loadHighScores = do  
  contents <- readFile "highscore.txt"  
  let scoreLines = lines contents 
  let scorePairs = convertStringstoPairs scoreLines
  return scorePairs     
  
saveHighScore :: GameState -> IO ()
saveHighScore game = do     
  writeFile "highscore.txt" $ unlines $ map (\pair -> fst pair ++ " " ++ snd pair) (scores (highScores game))

convertStringstoPairs :: [String] -> [(String, String)]
convertStringstoPairs scoreLines = map ((\[a,b] -> (a,b)) . splitOn " ") scoreLines