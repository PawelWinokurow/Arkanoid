module HighScoreView(module HighScoreView) where

import Textures
import GameObjects
import Settings
import Geometry
import System.IO  
import System.Exit
import Graphics.Gloss
import Graphics.Gloss.Interface.Pure.Game
import Graphics.Gloss.Interface.IO.Game

update :: Float -> GameState -> GameState
update seconds game = game 

render :: GameState  -> Picture
render game
  | isBackButtonHovered (buttonsHover game) = pictures $ [ backgroundHighScoreTex (textures game), translate 0 (-180) $ backButtonOnHoverTex (textures game) ] ++ (showHighScores game)
  | otherwise                               = pictures $ [ backgroundHighScoreTex (textures game), translate 0 (-180) $ backButtonTex (textures game) ] ++ (showHighScores game)    

showHighScores :: GameState -> [Picture]
showHighScores game = [translate 0 (100 + (-50) * fromIntegral row) $ (showHighScoreLine row) | row <- [0..(length $ scores (highScores game)) - 1]]
  where
    showHighScoreLine :: Int -> Picture
    showHighScoreLine row = pictures $  [translate (-180) 0 (convertStringToPicture $ fst $ (scores (highScores game))!!row), translate (40) 0 (convertStringToPicture $ snd $ (scores (highScores game))!!row)]

    convertStringToPicture :: String -> Picture
    convertStringToPicture text = pictures $ [ translate (fromIntegral (col * 38)) 0 (snd $ (filter (\symbol -> (fst symbol) == text!!col) (symbolsTex (textures game)))!!0) | col <- [0..length text - 1]]

handleInput :: Event -> GameState -> GameState
handleInput (EventMotion (x, y)) game = mouseMotionHandler game (x,y)
handleInput (EventKey (MouseButton LeftButton) Down _ (x, y)) game = mouseClickHandler game (x,y)
handleInput _ game = game

mouseClickHandler :: GameState -> Position -> GameState
mouseClickHandler game mousePosition 
  | isBackButtonHovered (buttonsHover game) = game {view = MainMenu}
  | otherwise                               = game {view = HighScores}

mouseMotionHandler :: GameState -> Position -> GameState
mouseMotionHandler game mousePosition = game { buttonsHover = (buttonsHover game) { isBackButtonHovered = mousePosition `inside` (0,(-180))  
} }