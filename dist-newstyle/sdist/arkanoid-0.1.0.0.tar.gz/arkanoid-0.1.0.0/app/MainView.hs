module MainView (module MainView) where

import GameView(initGameState)
import Textures
import GameObjects
import Settings
import Geometry
import Graphics.Gloss
import Graphics.Gloss.Interface.Pure.Game
import Graphics.Gloss.Interface.IO.Game

update :: Float -> GameState -> GameState
update seconds game = game 

render :: GameState  -> Picture
render game 
  | isNewGameButtonHovered   (buttonsHover game) = pictures $ [ backgroundMainTex (textures game), translate 0 70 $ newGameButtonOnHoverTex (textures game), highScoreButtonTex (textures game), translate 0 (-70) $ exitGameButtonTex (textures game) ]
  | isHighScoreButtonHovered (buttonsHover game) = pictures $ [ backgroundMainTex (textures game), translate 0 70 $ newGameButtonTex (textures game), highScoreButtonOnHoverTex (textures game), translate 0 (-70) $ exitGameButtonTex (textures game) ]
  | isExitGameButtonHovered  (buttonsHover game) = pictures $ [ backgroundMainTex (textures game), translate 0 70 $ newGameButtonTex (textures game), highScoreButtonTex (textures game), translate 0 (-70) $ exitGameButtonOnHoverTex (textures game) ]
  | otherwise                                    = pictures $ [ backgroundMainTex (textures game), translate 0 70 $ newGameButtonTex (textures game), highScoreButtonTex (textures game), translate 0 (-70) $ exitGameButtonTex (textures game) ]

handleInput :: Event -> GameState -> GameState
handleInput (EventMotion (x, y)) game = mouseMotionHandler game (x,y)
handleInput (EventKey (MouseButton LeftButton) Down _ (x, y)) game = mouseClickHandler game (x,y)
handleInput _ game = game

mouseClickHandler :: GameState -> Position -> GameState
mouseClickHandler game mousePosition 
  | isNewGameButtonHovered (buttonsHover game)   = startGame game
  | isHighScoreButtonHovered (buttonsHover game) = game {view = HighScores}
  | isExitGameButtonHovered (buttonsHover game)  = game {exit = True}
  | otherwise                                    = game {view = MainMenu}    
          
startGame :: GameState -> GameState
startGame game = GameView.initGameState game

mouseMotionHandler :: GameState -> Position -> GameState
mouseMotionHandler game mousePosition = game {buttonsHover = (buttonsHover game) { isNewGameButtonHovered = mousePosition `inside` (0, 70)  
                                                                                 , isHighScoreButtonHovered = mousePosition `inside` (0, 0)   
                                                                                 , isExitGameButtonHovered = mousePosition `inside` (0,(-70))  
                                                                                 } }