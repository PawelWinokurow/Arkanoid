module GameOverView (module GameOverView) where

import GameView(initGameState)
import Textures
import GameObjects
import Settings
import Geometry
import System.IO  
import System.Exit
import Data.List
import Data.Function
import Graphics.Gloss
import Graphics.Gloss.Interface.Pure.Game
import Graphics.Gloss.Interface.IO.Game

update :: Float -> GameState -> GameState
update seconds game = game 

render :: GameState  -> Picture
render game 
  | isReplayButtonHovered (buttonsHover game)   = pictures $ [ backgroundGameOverTex (textures game), translate 0 (-70) $ replayButtonOnHoverTex (textures game), translate 0 (-140) $ mainMenuButtonTex (textures game)] ++ [(showNewScore game)]
  | isMainMenuButtonHovered (buttonsHover game) = pictures $ [ backgroundGameOverTex (textures game), translate 0 (-70) $ replayButtonTex (textures game), translate 0 (-140) $ mainMenuButtonOnHoverTex (textures game)] ++ [(showNewScore game)]
  | otherwise                                   = pictures $ [ backgroundGameOverTex (textures game), translate 0 (-70) $ replayButtonTex (textures game), translate 0 (-140) $ mainMenuButtonTex (textures game) ] ++ [(showNewScore game)]  

showNewScore :: GameState -> Picture
showNewScore game = if (read (snd (score game)) ::Int) > minimum highscores
                        then
                          if isSaveButtonHovered (buttonsHover game)
                            then
                              pictures $ [translate (-120) 100 enterName, translate 30 100 (convertStringToPicture $ snd $ (score game)), saveButtonOnHoverTex (textures game)]
                            else
                              pictures $ [translate (-120) 100 enterName, translate 30 100 (convertStringToPicture $ snd $ (score game)), saveButtonTex (textures game)]
                      else
                        pictures $ []
  where 
    enterName :: Picture
    enterName = pictures $ [ convertStringToPicture (fst (score game)), addArrows ]

    addArrows :: Picture
    addArrows
      | isFirstUpButtonHovered (buttonsHover game)    = pictures $ [translate (fromIntegral (col * 38)) 40 (arrowUpTex (textures game))   | col <- [1, 2]] ++ 
                                                                   [translate (fromIntegral (col * 38)) (-40) (arrowDownTex (textures game)) | col <- [0..2]] ++
                                                                   [translate 0 40 (arrowUpOnHoverTex (textures game))]
      | isFirstDownButtonHovered (buttonsHover game)  = pictures $ [translate (fromIntegral (col * 38)) 40 (arrowUpTex (textures game))   | col <- [0..2]] ++ 
                                                                   [translate (fromIntegral (col * 38)) (-40) (arrowDownTex (textures game)) | col <- [1, 2]] ++
                                                                   [translate 0 (-40) (arrowDownOnHoverTex (textures game))]
      | isSecondUpButtonHovered (buttonsHover game)   = pictures $ [translate (fromIntegral (col * 38)) 40 (arrowUpTex (textures game))   | col <- [0, 2]] ++ 
                                                                   [translate (fromIntegral (col * 38)) (-40) (arrowDownTex (textures game)) | col <- [0..2]] ++
                                                                   [translate 38 40 (arrowUpOnHoverTex (textures game))]
      | isSecondDownButtonHovered (buttonsHover game) = pictures $ [translate (fromIntegral (col * 38)) 40 (arrowUpTex (textures game))   | col <- [0..2]] ++ 
                                                                   [translate (fromIntegral (col * 38)) (-40) (arrowDownTex (textures game)) | col <- [0, 2]] ++
                                                                   [translate 38 (-40) (arrowDownOnHoverTex (textures game))]
      | isThirdUpButtonHovered (buttonsHover game)    = pictures $ [translate (fromIntegral (col * 38)) 40 (arrowUpTex (textures game))   | col <- [0, 1]] ++ 
                                                                   [translate (fromIntegral (col * 38)) (-40) (arrowDownTex (textures game)) | col <- [0..2]] ++
                                                                   [translate 76 40 (arrowUpOnHoverTex (textures game))]
      | isThirdDownButtonHovered (buttonsHover game)  = pictures $ [translate (fromIntegral (col * 38)) 40 (arrowUpTex (textures game))   | col <- [0..2]] ++ 
                                                                   [translate (fromIntegral (col * 38)) (-40) (arrowDownTex (textures game)) | col <- [0, 1]] ++
                                                                   [translate 76 (-40) (arrowDownOnHoverTex (textures game))]
      | otherwise                                     = pictures $ [translate (fromIntegral (col * 38)) 40 (arrowUpTex (textures game))   | col <- [0..2]] ++ 
                                                                   [translate (fromIntegral (col * 38)) (-40) (arrowDownTex (textures game)) | col <- [0..2]]

    convertStringToPicture :: String -> Picture
    convertStringToPicture text = pictures $ [ translate (fromIntegral (col * 38)) 0 (snd $ (filter (\symbol -> (fst symbol) == text!!col) (symbolsTex (textures game)))!!0) | col <- [0..length text - 1]]

    highscores :: [Int]
    highscores = map (\scorePair -> read (snd scorePair) ::Int) (scores (highScores game))


handleInput :: Event -> GameState -> GameState
handleInput (EventMotion (x, y)) game = mouseMotionHandler game (x,y)
handleInput (EventKey (MouseButton LeftButton) Down _ (x, y)) game = mouseClickHandler game (x,y)
handleInput _ game = game

mouseClickHandler :: GameState -> Position -> GameState
mouseClickHandler game mousePosition
  | isFirstUpButtonHovered (buttonsHover game)    = game {score = ([fst $ (symbolsTex (textures game))!!(nextIndex 0)] ++ slice 1 2 (fst (score game)), snd (score game))}
  | isFirstDownButtonHovered (buttonsHover game)  = game {score = ([fst $ (symbolsTex (textures game))!!(prevIndex 0)] ++ slice 1 2 (fst (score game)), snd (score game))}
  | isSecondUpButtonHovered (buttonsHover game)   = game {score = ([(fst (score game))!!0] ++ [fst $ (symbolsTex (textures game))!!(nextIndex 1)] ++ [(fst (score game))!!2], snd (score game))}
  | isSecondDownButtonHovered (buttonsHover game) = game {score = ([(fst (score game))!!0] ++ [fst $ (symbolsTex (textures game))!!(prevIndex 1)] ++ [(fst (score game))!!2], snd (score game))}
  | isThirdUpButtonHovered (buttonsHover game)    = game {score = (slice 0 1 (fst (score game)) ++ [fst $ (symbolsTex (textures game))!!(nextIndex 2)], snd (score game))}
  | isThirdDownButtonHovered (buttonsHover game)  = game {score = (slice 0 1 (fst (score game)) ++ [fst $ (symbolsTex (textures game))!!(prevIndex 2)], snd (score game))}
  | isReplayButtonHovered (buttonsHover game)     = startGame game
  | isMainMenuButtonHovered (buttonsHover game)   = game {view = MainMenu}
  | isSaveButtonHovered (buttonsHover game)       = addScore
  | otherwise                                     = game {view = GameOver}  
  where
    nextIndex :: Int -> Int
    nextIndex i = ((fromJust $ findIndex (\pair -> (fst pair) == (fst (score game))!!i) (symbolsTex (textures game))) + 1) `mod` 36

    prevIndex :: Int -> Int
    prevIndex i = ((fromJust $ findIndex (\pair -> (fst pair) == (fst (score game))!!i) (symbolsTex (textures game))) - 1) `mod` 36

    fromJust :: Maybe a -> a
    fromJust (Just a) = a

    addScore :: GameState
    addScore =  game {view = MainMenu, highScores = (highScores game) {save = True, scores = take 5 $ reverse $ sortBy (\ (_, x) (_, y) -> compare (read x ::Int) (read y ::Int)) ((scores (highScores game)) ++ [score game]) } }

    slice :: Int -> Int -> [a] -> [a]
    slice from to xs = take (to - from + 1) (drop from xs)

startGame :: GameState -> GameState
startGame game = GameView.initGameState game

mouseMotionHandler :: GameState -> Position -> GameState
mouseMotionHandler game mousePosition = game { buttonsHover = (buttonsHover game) { isReplayButtonHovered     = mousePosition `inside` (0, (-70))
                                                                                  , isMainMenuButtonHovered   = mousePosition `inside` (0, (-140))
                                                                                  , isSaveButtonHovered       = mousePosition `inside` (0,0) 
                                                                                  , isFirstUpButtonHovered    = mousePosition `inside` ((-120), 140)
                                                                                  , isFirstDownButtonHovered  = mousePosition `inside` ((-120), 60)
                                                                                  , isSecondUpButtonHovered   = mousePosition `inside` ((-82), 140)
                                                                                  , isSecondDownButtonHovered = mousePosition `inside` ((-82), 60) 
                                                                                  , isThirdUpButtonHovered    = mousePosition `inside` ((-44), 140)
                                                                                  , isThirdDownButtonHovered  = mousePosition `inside` ((-44), 60)
                                                                                  }                                                                                  
                                             }