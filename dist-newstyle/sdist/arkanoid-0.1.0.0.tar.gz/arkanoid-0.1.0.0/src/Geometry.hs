module Geometry (module Geometry) where

import Settings
import Graphics.Gloss

type Radius = Float 
type Position = (Float, Float)
type Velocity = Position

getColor :: Int -> Color
getColor row
  | (row `mod` 5) == 0 = red 
  | (row `mod` 5) == 1 = green  
  | (row `mod` 5) == 2 = blue  
  | (row `mod` 5) == 3 = yellow  
  | (row `mod` 5) == 4 = white    

nextColor :: Color -> Color
nextColor color
  | color == red = green
  | color == green = blue
  | color == blue = yellow
  | color == yellow = white
  | color == white = red

distanceX :: Position -> Position -> Float
distanceX ballPosition cellPosition = abs ((fst ballPosition) - (fst cellPosition)) - cellWidth / 2 - ballRadius

distanceY :: Position -> Position -> Float
distanceY ballPosition cellPosition = abs ((snd ballPosition) - (snd cellPosition)) - cellHeight / 2 - ballRadius

cellPositionX :: Int -> Float
cellPositionX col = -fromIntegral screenWidth / 2 + cellMarginLeft + (cellWidth + cellMarginBetween) * (fromIntegral col) + (cellWidth / 2)

cellPositionY :: Int -> Float
cellPositionY row = -80 + fromIntegral screenHeight / 2 - cellMarginTop - (cellHeight + cellMarginBetween) * (fromIntegral row) - (cellHeight / 2)