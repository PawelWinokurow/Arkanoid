module GameCollisions (module GameCollisions) where

import Settings
import Geometry
import GameObjects

data CollisionDirection = LeftCollision | TopCollision | RightCollision | BottomCollision | VerticalCollision | HorizontalCollision

wallCollision :: GameState -> CollisionDirection -> Bool
wallCollision game direction = case direction of LeftCollision -> x - ballRadius <= -fromIntegral screenWidth / 2 
                                                 TopCollision -> y + ballRadius >= fromIntegral screenHeight / 2
                                                 RightCollision -> x + ballRadius >= fromIntegral screenWidth / 2
                                                 BottomCollision -> y - ballRadius <= -fromIntegral screenHeight / 2
  where 
    (x, y) = ballPosition $ ball game

paddleCollision :: GameState -> Bool 
paddleCollision game = 
  ballPositionY - ballRadius <= paddlePositionY + paddleHeight / 2 
  && ballPositionX >= paddlePositionX - (paddleWidth $ paddle game) / 2 
  && ballPositionX <= paddlePositionX + (paddleWidth $ paddle game) / 2 
  where 
    ballPositionX = fst (ballPosition $ ball game)
    ballPositionY = snd (ballPosition $ ball game)
    paddlePositionX = fst (paddlePosition $ paddle game)
    paddlePositionY = snd (paddlePosition $ paddle game)

cellCollision :: GameState -> CollisionDirection -> Bool 
cellCollision game direction = 
  if length (cells game) == 0 
    then False
  else case direction of HorizontalCollision -> checkHorizontalCollision (cells game) (ballPosition $ ball game)
                         VerticalCollision -> checkVerticalCollision (cells game) (ballPosition $ ball game)
  where 
    checkHorizontalCollision :: [Cell] -> Position -> Bool
    checkHorizontalCollision [] _ = False
    checkHorizontalCollision (x:xs) ballPosition = 
      if distanceX ballPosition (cellPosition x) <= 0 && distanceY ballPosition (cellPosition x) <= 0 
          && pi / 4 < atan ((distanceY ballPosition (cellPosition x)) / (distanceX ballPosition (cellPosition x))) 
          && atan ((distanceY ballPosition (cellPosition x)) / (distanceX ballPosition (cellPosition x))) <  pi / 2
        then
          True
        else
          checkHorizontalCollision xs ballPosition 
    
    checkVerticalCollision :: [Cell] -> Position -> Bool
    checkVerticalCollision [] _ = False
    checkVerticalCollision (x:xs) ballPosition = 
      if distanceY ballPosition (cellPosition x) <= 0 && distanceX ballPosition (cellPosition x) <= 0
          && 0 < atan ((distanceY ballPosition (cellPosition x)) / (distanceX ballPosition (cellPosition x))) 
          && atan ((distanceY ballPosition (cellPosition x)) / (distanceX ballPosition (cellPosition x))) <  pi / 4
        then
          True
        else
          checkVerticalCollision xs ballPosition 