module Textures (module Textures) where

import Graphics.Gloss

data Textures = Textures 
  { backgroundGameTex         :: Picture
  , paddleTex                 :: Picture
  , ballTex                   :: Picture
  , backgroundMainTex         :: Picture
  , newGameButtonTex          :: Picture
  , newGameButtonOnHoverTex   :: Picture
  , highScoreButtonTex        :: Picture
  , highScoreButtonOnHoverTex :: Picture
  , backgroundGameOverTex     :: Picture
  , replayButtonTex           :: Picture
  , replayButtonOnHoverTex    :: Picture
  , saveButtonTex             :: Picture
  , saveButtonOnHoverTex      :: Picture
  , mainMenuButtonTex         :: Picture
  , mainMenuButtonOnHoverTex  :: Picture
  , exitGameButtonTex         :: Picture
  , exitGameButtonOnHoverTex  :: Picture
  , backButtonTex             :: Picture
  , backButtonOnHoverTex      :: Picture
  , backgroundHighScoreTex    :: Picture
  , arrowUpTex                :: Picture
  , arrowDownTex              :: Picture
  , arrowUpOnHoverTex         :: Picture
  , arrowDownOnHoverTex       :: Picture
  , numsTex                   :: [(Char, Picture)]
  , symbolsTex                :: [(Char, Picture)]
  }

loadTextures :: IO Textures
loadTextures = do
  backgroundGameImage         <- loadBMP "textures/game/background.bmp"
  paddleImage                 <- loadBMP "textures/game/paddle.bmp"
  ballImage                   <- loadBMP "textures/game/ball.bmp"
  backgroundMainImage         <- loadBMP "textures/main/background_main.bmp"
  newGameButtonImage          <- loadBMP "textures/main/new_game_button.bmp"
  newGameButtonOnHoverImage   <- loadBMP "textures/main/new_game_button_on_hover.bmp"
  highScoreButtonImage        <- loadBMP "textures/main/highscore_button.bmp"
  highScoreButtonOnHoverImage <- loadBMP "textures/main/highscore_button_on_hover.bmp"
  exitGameButtonImage         <- loadBMP "textures/main/exit_game_button.bmp"
  exitGameButtonOnHoverImage  <- loadBMP "textures/main/exit_game_button_on_hover.bmp"
  backgroundGameOverImage     <- loadBMP "textures/gameover/background_gameover.bmp"
  replayButtonImage           <- loadBMP "textures/gameover/replay_button.bmp"
  replayButtonOnHoverImage    <- loadBMP "textures/gameover/replay_button_on_hover.bmp"
  saveButtonImage             <- loadBMP "textures/gameover/save_button.bmp"
  saveButtonOnHoverImage      <- loadBMP "textures/gameover/save_button_on_hover.bmp"
  mainMenuButtonImage         <- loadBMP "textures/gameover/main_menu_button.bmp"
  mainMenuButtonOnHoverImage  <- loadBMP "textures/gameover/main_menu_button_on_hover.bmp"
  arrowUpImage                <- loadBMP "textures/gameover/up.bmp"
  arrowDownImage              <- loadBMP "textures/gameover/down.bmp"
  arrowUpOnHoverImage         <- loadBMP "textures/gameover/up_on_hover.bmp"
  arrowDownOnHoverImage       <- loadBMP "textures/gameover/down_on_hover.bmp"
  backButtonImage             <- loadBMP "textures/highscores/back_button.bmp"
  backButtonOnHoverImage      <- loadBMP "textures/highscores/back_button_on_hover.bmp"
  backgroundHighScoreImage    <- loadBMP "textures/highscores/background_highscores.bmp"
  numsImages                  <- loadNumbers
  alphaImages                 <- loadAlpha

  let textures = Textures { backgroundGameTex = backgroundGameImage 
                          , paddleTex = paddleImage
                          , ballTex = ballImage
                          , backgroundMainTex = backgroundMainImage 
                          , newGameButtonTex = newGameButtonImage
                          , newGameButtonOnHoverTex = newGameButtonOnHoverImage
                          , highScoreButtonTex = highScoreButtonImage
                          , highScoreButtonOnHoverTex = highScoreButtonOnHoverImage
                          , backgroundGameOverTex = backgroundGameOverImage
                          , replayButtonTex = replayButtonImage
                          , replayButtonOnHoverTex = replayButtonOnHoverImage
                          , saveButtonTex = saveButtonImage
                          , saveButtonOnHoverTex = saveButtonOnHoverImage
                          , mainMenuButtonTex = mainMenuButtonImage
                          , mainMenuButtonOnHoverTex = mainMenuButtonOnHoverImage
                          , exitGameButtonTex = exitGameButtonImage
                          , exitGameButtonOnHoverTex = exitGameButtonOnHoverImage
                          , backButtonTex = backButtonImage
                          , backButtonOnHoverTex = backButtonOnHoverImage
                          , backgroundHighScoreTex = backgroundHighScoreImage
                          , numsTex = numsImages
                          , symbolsTex = alphaImages
                          , arrowUpOnHoverTex = arrowUpOnHoverImage 
                          , arrowDownOnHoverTex = arrowDownOnHoverImage 
                          , arrowUpTex = arrowUpImage 
                          , arrowDownTex = arrowDownImage 
                          }
  return textures

loadNumbers :: IO [(Char, Picture)]
loadNumbers = 
  do
    nums <- sequence [ loadBMP ("textures/symbols/nums/" ++ [ch] ++ ".bmp") | ch <- ['0'..'9'] ]
    let listOfPairs = zip ['0'..'9'] nums
    return listOfPairs

loadAlpha :: IO [(Char, Picture)]
loadAlpha = 
  do
    alpha <- sequence [ loadBMP ("textures/symbols/alpha/" ++ [ch] ++ ".bmp") | ch <- ['A'..'Z'] ]
    nums <- sequence [ loadBMP ("textures/symbols/alpha/" ++ [ch] ++ ".bmp") | ch <- ['0'..'9'] ]
    let listOfPairs = (zip ['a'..'z'] alpha) ++ (zip ['0'..'9'] nums)
    return listOfPairs