{-# LANGUAGE FlexibleInstances #-}
module GameObjects (module GameObjects) where

import Geometry
import Textures
import Settings
import Graphics.Gloss
import Control.Lens

data View = MainMenu | GameInProgress | GameExit | GameOver | HighScores
  deriving (Show, Eq)

data BonusType = Expansion
  deriving (Eq)

data Cell = Cell
  { cellPosition :: Position
  , picture      :: Picture
  , row          :: Int
  , cellColor    :: Color
  } deriving (Show)

data BallState = Ball 
  { ballPosition    :: Position
  , ballVelocity    :: Velocity   
  }

data BonusState = Bonus 
  { bonusPosition   :: Position
  , bonusVelocity   :: Velocity
  , bonusType       :: BonusType    
  }

data PaddleState = Paddle 
  { paddlePosition  :: Position       
  , paddleVelocityX :: Float          
  , paddleWidth     :: Float   
  }

data HighScores = Scores
  { save                :: Bool
  , scores              :: [(String, String)]
  }

data ButtonsHover = Buttons
  { isNewGameButtonHovered    :: Bool
  , isHighScoreButtonHovered  :: Bool
  , isReplayButtonHovered     :: Bool
  , isSaveButtonHovered       :: Bool
  , isExitGameButtonHovered   :: Bool
  , isBackButtonHovered       :: Bool
  , isMainMenuButtonHovered   :: Bool
  , isFirstUpButtonHovered    :: Bool
  , isFirstDownButtonHovered  :: Bool
  , isSecondUpButtonHovered   :: Bool
  , isSecondDownButtonHovered :: Bool
  , isThirdUpButtonHovered    :: Bool
  , isThirdDownButtonHovered  :: Bool
  }

data GameState = Game
  { ball                      :: BallState       
  , paddle                    :: PaddleState
  , score                     :: (String, String)       
  , textures                  :: Textures
  , cells                     :: [Cell]
  , bonuses                   :: [BonusState]
  , view                      :: View
  , exit                      :: Bool
  , buttonsHover              :: ButtonsHover
  , highScores                :: HighScores
  }

class CursorInsideButton a where
  inside :: a -> a -> Bool

instance CursorInsideButton Position where
  inside mousePosition buttonPosition =
    fst mousePosition >= fst buttonPosition + (-buttonWidth) / 2 
    && fst mousePosition <= fst buttonPosition + buttonWidth / 2    
    && snd mousePosition >= snd buttonPosition + (- buttonHeight) / 2    
    && snd mousePosition <= snd buttonPosition + buttonHeight / 2 
 