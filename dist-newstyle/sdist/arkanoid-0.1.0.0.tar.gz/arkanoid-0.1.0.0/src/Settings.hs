module Settings (module Settings) where

screenWidth, screenHeight, screenOffset, fps :: Int
screenWidth =  1024
screenHeight = 768
screenOffset = 100
fps = 60

ballRadius, paddleHeight, buttonHeight, buttonWidth, arrowButtonHeight, arrowButtonWidth :: Float
ballRadius = 10
paddleHeight = 32
buttonWidth = 150
buttonHeight = 50
arrowButtonHeight = 20
arrowButtonWidth = 40

cellCols, cellRows :: Int
cellCols = 10
cellRows = 5

cellWidth, cellHeight, cellMarginLeft, cellMarginTop, cellMarginBetween :: Float
cellWidth = 100
cellHeight = 50
cellMarginLeft = 3
cellMarginTop = 3
cellMarginBetween = 2 

symbolHeight, symbolWidth :: Int
symbolHeight = 72
symbolWidth = 72