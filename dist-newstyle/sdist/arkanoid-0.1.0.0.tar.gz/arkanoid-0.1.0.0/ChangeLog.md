# Changelog for arkanoid

## Unreleased changes
